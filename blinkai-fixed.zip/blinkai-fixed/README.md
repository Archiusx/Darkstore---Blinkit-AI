# BlinkAI — Smart Dark Store IMS

> An AI-powered Inventory Management System for Blinkit-style dark stores, featuring real-time stock tracking, hyperlocal demand forecasting with Google Gemini, barcode scanning, expiry monitoring, and optimised picker workflows.

![React](https://img.shields.io/badge/React-19-61DAFB?logo=react&logoColor=white)
![TypeScript](https://img.shields.io/badge/TypeScript-5.8-3178C6?logo=typescript&logoColor=white)
![Firebase](https://img.shields.io/badge/Firebase-12-FFCA28?logo=firebase&logoColor=black)
![Vite](https://img.shields.io/badge/Vite-6-646CFF?logo=vite&logoColor=white)
![Tailwind CSS](https://img.shields.io/badge/Tailwind-4-06B6D4?logo=tailwindcss&logoColor=white)
![Vercel](https://img.shields.io/badge/Deploy-Vercel-000000?logo=vercel&logoColor=white)

---

## Table of Contents

- [Features](#features)
- [Tech Stack](#tech-stack)
- [Project Structure](#project-structure)
- [Prerequisites](#prerequisites)
- [Local Development Setup](#local-development-setup)
- [Firebase Setup](#firebase-setup)
- [Gemini AI Setup](#gemini-ai-setup)
- [Environment Variables Reference](#environment-variables-reference)
- [Deploying to Vercel](#deploying-to-vercel)
- [Role and Permissions System](#role-and-permissions-system)
- [Firestore Data Model](#firestore-data-model)
- [Contributing](#contributing)

---

## Features

| Feature | Description |
|---|---|
| 📦 **Inventory Management** | Real-time CRUD for SKUs with drag-and-drop reordering |
| 🤖 **AI Demand Forecasting** | Gemini 2.0 Flash predicts demand spikes based on local context |
| 📷 **Barcode Scanner** | HTML5 camera-based QR / barcode scanning for picking |
| ⏰ **Expiry Tracking** | Automatic alerts for items expiring within 7 days |
| 🗺️ **Shelf Slotting Optimisation** | AI suggests adjacent placement for frequently co-picked items |
| 👷 **Picker Workflows** | Guided order-picking with scan-confirm, skip-with-reason, and emergency complete |
| 🔔 **Approval Requests** | Manager-gated approvals for stock changes and emergency completions |
| 🌡️ **Compliance Monitoring** | Temperature, cleaning, and regulatory compliance logging |
| 💬 **Vendor Messaging** | In-app messaging between store staff and vendors |
| 📊 **Analytics Dashboard** | Stock health, picking stats, compliance trends |
| 🌙 **Dark Mode** | Full dark-mode support across all views |
| 🔐 **Auth and RBAC** | Google Sign-In with Admin / Manager / Picker roles enforced in Firestore rules |

---

## Tech Stack

- **Frontend:** React 19, TypeScript 5.8, Vite 6
- **Styling:** Tailwind CSS v4 (CSS-first config), Framer Motion via `motion`
- **Drag and Drop:** `@dnd-kit/core` and `@dnd-kit/sortable`
- **Database and Auth:** Firebase Firestore v12, Firebase Auth (Google provider)
- **AI:** Google Gemini 2.0 Flash via `@google/genai`
- **Barcode Scanning:** `html5-qrcode`
- **Icons:** `lucide-react`
- **Deployment:** Vercel (static SPA)

---

## Project Structure

```
blinkai-dark-store-ims/
├── src/
│   ├── components/
│   │   └── Scanner.tsx          # Barcode/QR camera scanner component
│   ├── services/
│   │   └── geminiService.ts     # Gemini AI: demand forecast + slotting
│   ├── App.tsx                  # Main app — all views and state
│   ├── firebase.ts              # Firebase init (reads from env vars)
│   ├── index.css                # Tailwind v4 CSS-first theme config
│   └── main.tsx                 # React root entry point
├── firestore.rules              # Firestore security rules
├── firebase-blueprint.json      # Data model schema reference
├── .env.example                 # Template — copy to .env.local
├── index.html
├── package.json
├── tsconfig.json
└── vite.config.ts
```

---

## Prerequisites

- **Node.js** v18 or later — [nodejs.org](https://nodejs.org)
- **npm** v9 or later (ships with Node)
- **Git** — [git-scm.com](https://git-scm.com)
- A **Google account** (for Firebase and Gemini API)
- A **Vercel account** (free tier works fine) — [vercel.com](https://vercel.com)

---

## Local Development Setup

### 1. Clone the repository

```bash
git clone https://github.com/YOUR_USERNAME/blinkai-dark-store-ims.git
cd blinkai-dark-store-ims
```

### 2. Install dependencies

```bash
npm install
```

### 3. Configure environment variables

```bash
cp .env.example .env.local
```

Open `.env.local` and fill in all the values. See the sections below and the [Environment Variables Reference](#environment-variables-reference) table for what each one is.

### 4. Start the dev server

```bash
npm run dev
```

The app will open at **http://localhost:3000**

---

## Firebase Setup

### Step 1 — Create a project

1. Go to [console.firebase.google.com](https://console.firebase.google.com)
2. Click **Add project**, give it a name (e.g. `blinkai-ims`), follow the wizard
3. Disable Google Analytics if you don't need it

### Step 2 — Register a Web app

1. In the project dashboard click the **`</>`** (Web) icon
2. Give the app a nickname, e.g. `BlinkAI Web`
3. Skip Firebase Hosting — we use Vercel
4. Click **Register app**
5. Copy the config object shown — you'll paste these values into your env file:

```js
// Example — yours will differ
apiKey: "AIzaSy..."
authDomain: "your-project.firebaseapp.com"
projectId: "your-project-id"
storageBucket: "your-project.firebasestorage.app"
messagingSenderId: "123456789"
appId: "1:123456789:web:abc123"
```

### Step 3 — Enable Firestore

1. Sidebar: **Build → Firestore Database → Create database**
2. Choose **Start in production mode**
3. Pick a region (e.g. `asia-south1` for India)
4. Click **Done**

> If you created a **named** database (not the `(default)` one), put its ID in `VITE_FIREBASE_FIRESTORE_DB_ID`. Otherwise leave that variable blank.

### Step 4 — Enable Google Authentication

1. Sidebar: **Build → Authentication → Get started**
2. Under **Sign-in method** enable **Google**
3. Set a support email and save

### Step 5 — Deploy Firestore Security Rules

```bash
npm install -g firebase-tools
firebase login
firebase use --add          # select your project when prompted
firebase deploy --only firestore:rules
```

---

## Gemini AI Setup

1. Visit [aistudio.google.com/app/apikey](https://aistudio.google.com/app/apikey)
2. Click **Create API key**
3. Copy the key into `VITE_GEMINI_API_KEY` in your `.env.local`

The app uses **Gemini 2.0 Flash** for demand forecasting and shelf slotting optimisation. The free tier is sufficient for development.

---

## Environment Variables Reference

All variables are prefixed `VITE_` so Vite exposes them to the browser bundle.

| Variable | Required | Where to get it |
|---|---|---|
| `VITE_GEMINI_API_KEY` | Yes | [aistudio.google.com/app/apikey](https://aistudio.google.com/app/apikey) |
| `VITE_FIREBASE_API_KEY` | Yes | Firebase Console → Project Settings → Your apps |
| `VITE_FIREBASE_AUTH_DOMAIN` | Yes | Same as above |
| `VITE_FIREBASE_PROJECT_ID` | Yes | Same as above |
| `VITE_FIREBASE_STORAGE_BUCKET` | Yes | Same as above |
| `VITE_FIREBASE_MESSAGING_SENDER_ID` | Yes | Same as above |
| `VITE_FIREBASE_APP_ID` | Yes | Same as above |
| `VITE_FIREBASE_FIRESTORE_DB_ID` | Optional | Named Firestore DB ID; leave blank for `(default)` |
| `VITE_ADMIN_EMAIL` | Yes | The Google email auto-assigned Admin role on first login |

> **Security:** Never commit `.env.local` to Git. It is already listed in `.gitignore`.

---

## Deploying to Vercel

### Option A — Vercel Dashboard

1. Push your code to GitHub
2. Go to [vercel.com/new](https://vercel.com/new) and import your repository
3. Vercel auto-detects Vite. Confirm:
   - **Framework Preset:** Vite
   - **Build Command:** `npm run build`
   - **Output Directory:** `dist`
4. Expand **Environment Variables** and add every key from `.env.example` with real values
5. Click **Deploy**

### Option B — Vercel CLI

```bash
npm install -g vercel
vercel login
vercel --prod
```

### Post-deployment steps

After your first deploy, add your Vercel domain to Firebase's authorised list:

1. Firebase Console → **Authentication → Settings → Authorized domains**
2. Click **Add domain** and enter your `your-app.vercel.app` URL

---

## Role and Permissions System

| Role | Access |
|---|---|
| **Admin** | Full access. Auto-assigned to the email in `VITE_ADMIN_EMAIL` on first login. |
| **Manager** | Write inventory and compliance, approve/reject requests. Assigned manually in Firestore. |
| **Picker** | Read inventory, create orders, submit tickets and approval requests. Default for new users. |

### Promoting a user to Manager

1. Sign in to the app with the account to promote
2. In Firebase Console → Firestore → `users` collection
3. Find the document matching that user's UID
4. Set the `role` field to `"Manager"`

---

## Firestore Data Model

| Collection | Description |
|---|---|
| `users` | Profiles: `role`, `email`, `displayName` |
| `inventory` | SKU records; subcollection `history` for stock adjustments |
| `compliance` | Temperature, cleaning, and regulatory check-ins |
| `tickets` | Issues raised by pickers |
| `approvals` | Manager-gated approval requests |
| `vendor_messages` | Staff-to-vendor messaging |
| `orders` | Picking order records |
| `picker_status` | Real-time picker activity and zone |

Full schema with field types is in `firebase-blueprint.json`.

---

## Available Scripts

| Script | Description |
|---|---|
| `npm run dev` | Start dev server on http://localhost:3000 |
| `npm run build` | Production build to `dist/` |
| `npm run preview` | Preview the production build locally |
| `npm run lint` | TypeScript type-check without emitting files |
| `npm run clean` | Remove the `dist/` folder |

---

## Contributing

1. Fork the repo
2. Create a feature branch: `git checkout -b feat/my-feature`
3. Commit your changes: `git commit -m 'feat: add my feature'`
4. Push: `git push origin feat/my-feature`
5. Open a Pull Request

---

## License

MIT © BlinkAI Contributors
